package com.ws.pruebaTecnica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaTecnicaNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
