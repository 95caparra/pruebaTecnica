package com.ws.pruebaTecnica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.pruebaTecnica"})
public class PruebaTecnicaNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaTecnicaNewApplication.class, args);
	}

}
