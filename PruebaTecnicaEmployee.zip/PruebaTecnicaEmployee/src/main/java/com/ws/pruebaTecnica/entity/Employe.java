package com.ws.pruebaTecnica.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "employe")
public class Employe implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotEmpty(message ="no puede estar vacio")
	@Column(name="emp_name",unique = true, nullable = false, length = 20)
	private String employeName;
	
	@NotEmpty(message ="no puede estar vacio")
	@Column(name="password",unique = true, nullable = false, length = 20)
	private String password;
	
	@NotEmpty(message ="no puede estar vacio")
	@Column(name="gender", nullable = false, length = 20)
	private String gender;
	
	@Column(name="birthday")
	private Date birthday;
	
	@Column(name="dep_id", length = 8)
	private Integer depId;
	
	@Column(name="imp_role_id", length = 8)
	private Integer impRoleId;
	
	@Column(name="rank", length = 8)
	private Integer rank;
	
	@Column(name="tel",unique = true, length = 20)
	private String telefono;
	
	@Column(name="email",unique = true, length = 30)
	private String email;
	
	@Column(name="info",unique = true, length = 200)
	private String info;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmployeName() {
		return employeName;
	}

	public void setEmployeName(String employeName) {
		this.employeName = employeName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public Integer getDepId() {
		return depId;
	}

	public void setDepId(Integer depId) {
		this.depId = depId;
	}

	public Integer getImpRoleId() {
		return impRoleId;
	}

	public void setImpRoleId(Integer impRoleId) {
		this.impRoleId = impRoleId;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
