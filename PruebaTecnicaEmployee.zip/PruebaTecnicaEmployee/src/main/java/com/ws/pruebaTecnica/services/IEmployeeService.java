package com.ws.pruebaTecnica.services;

import java.util.List;

import com.ws.pruebaTecnica.entity.Employe;

public interface IEmployeeService {
	
	public List<Employe> findAllEmployees();

}
