package com.ws.pruebaTecnica.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ws.pruebaTecnica.dao.IEmployeDAO;
import com.ws.pruebaTecnica.entity.Employe;
import com.ws.pruebaTecnica.services.IEmployeeService;

public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	private IEmployeDAO iEmployeDAO;
	
	@Override
	public List<Employe> findAllEmployees() {
		return iEmployeDAO.findAll();
	}

}
