package com.ws.pruebaTecnica.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ws.pruebaTecnica.entity.Employe;

public interface IEmployeDAO extends JpaRepository<Employe, Long>{

}
