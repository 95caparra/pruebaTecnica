package com.ws.pruebaTecnica.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import com.ws.pruebaTecnica.entity.Employe;
import com.ws.pruebaTecnica.services.IEmployeeService;

public class EmployeeController {
	
	@Autowired
	private IEmployeeService employeService;
	
	@GetMapping("/employees")
	public List<Employe> index() {
		return employeService.findAllEmployees();
	}

}
