
/* Populate tabla  */

/* Creamos algún empleado */
INSERT INTO `employe` (emp_name, password, gender, birthday, dep_id, imp_role_id, rank, tel, email, info) VALUES ('Camilo Ochoa', '$2a$10$C3Ul', 'Masculino','1995-06-17', 1, 1,1,'3154990765', '95camilo.ochoa@gmail.com', 'ingeniero de software');